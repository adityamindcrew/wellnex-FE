import SignInPage from "@/app/signin/sign-in-page";

export default function SignIn() {
  return <SignInPage />;
}