import CreateAccount from "./create-account";


export default function Home() {
  return <CreateAccount />
}
